//
//  pzApp.swift
//  pz
//
//  Created by Patrycja Zadziłko on 10/04/2024.
//

import SwiftUI

@main
struct pzApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
