#!/bin/sh
open -a Terminal .
